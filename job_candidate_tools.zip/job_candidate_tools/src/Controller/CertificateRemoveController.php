<?php
// only remove the reference to the certificate from the candidate node
// namespace Drupal\job_candidate_tools\Controller;

// use Drupal\Core\Controller\ControllerBase;
// use Symfony\Component\HttpFoundation\RedirectResponse;
// use Drupal\node\Entity\Node;

// class CertificateRemoveController extends ControllerBase {

//   public function removeCertificate($candidate, $certificate) {
//     $candidate_node = Node::load($candidate);
//     if ($candidate_node && $candidate_node->bundle() == 'job_candidate') {
//       $field = 'field_certificate';
//       if ($candidate_node->hasField($field)) {
//         $values = $candidate_node->get($field)->getValue();
//         $filtered = array_filter($values, function ($item) use ($certificate) {
//           return $item['target_id'] != $certificate;
//         });
//         $candidate_node->set($field, array_values($filtered));
//         $candidate_node->save();
//         $this->messenger()->addMessage(t('Certificate removed successfully.'));
//       }
//     }
//     return new RedirectResponse(\Drupal::request()->server->get('HTTP_REFERER'));
//   }
// }
// remove the reference to the certificate from the candidate node and set the certificate status to "Delete"
// namespace Drupal\job_candidate_tools\Controller;

// use Drupal\Core\Controller\ControllerBase;
// use Symfony\Component\HttpFoundation\RedirectResponse;
// use Drupal\node\Entity\Node;
// use Drupal\taxonomy\Entity\Term;

// class CertificateRemoveController extends ControllerBase {

//   public function removeCertificate($candidate, $certificate) {
//     $candidate_node = Node::load($candidate);
//     $certificate_node = Node::load($certificate);

//     if ($candidate_node && $candidate_node->bundle() == 'job_candidate') {
//       $field = 'field_certificate';

//       if ($candidate_node->hasField($field)) {
//         // 1️⃣ Remove the reference.
//         $values = $candidate_node->get($field)->getValue();
//         $filtered = array_filter($values, function ($item) use ($certificate) {
//           return $item['target_id'] != $certificate;
//         });
//         $candidate_node->set($field, array_values($filtered));
//         $candidate_node->save();

//         // 2️⃣ Update certificate status to "Delete".
//         if ($certificate_node && $certificate_node->hasField('field_status')) {
//           // Find taxonomy term with name "Delete"
//           $terms = \Drupal::entityTypeManager()
//             ->getStorage('taxonomy_term')
//             ->loadByProperties([
//               'name' => 'Delete',
//               'vid' => 'status', // vocabulary machine name
//             ]);
//           $delete_term = reset($terms);

//           if ($delete_term) {
//             $certificate_node->set('field_status', $delete_term->id());
//             $certificate_node->save();
//           }
//         }

//         $this->messenger()->addMessage($this->t('Certificate removed and status updated to Delete.'));
//       }
//     }

//     return new RedirectResponse(\Drupal::request()->server->get('HTTP_REFERER'));
//   }

// }
// set status delete on the certificate node and hide the node drom the candidate node
namespace Drupal\job_candidate_tools\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\node\Entity\Node;

class CertificateRemoveController extends ControllerBase {

  public function removeCertificate($candidate, $certificate) {
    $candidate_node = Node::load($candidate);
    $certificate_node = Node::load($certificate);

    if ($candidate_node && $candidate_node->bundle() == 'job_candidate' && $certificate_node) {

      // 1️⃣ Update certificate status to "Delete"
      if ($certificate_node->hasField('field_status')) {
        // Find taxonomy term "Delete" in vocabulary "status"
        $terms = \Drupal::entityTypeManager()
          ->getStorage('taxonomy_term')
          ->loadByProperties([
            'name' => 'Delete',
            'vid' => 'status', // vocabulary machine name
          ]);
        $delete_term = reset($terms);

        if ($delete_term) {
          $certificate_node->set('field_status', $delete_term->id());
          $certificate_node->save();
          $this->messenger()->addMessage($this->t('Certificate marked as deleted.'));
        }
        else {
          $this->messenger()->addError($this->t('Delete term not found in Status vocabulary.'));
        }
      }
    }

    return new RedirectResponse(\Drupal::request()->server->get('HTTP_REFERER'));
  }

}
