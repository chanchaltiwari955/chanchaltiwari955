// (function ($, Drupal) {
//     $(document).ready(function(){
//         $('.slick--view--promotions-carousel').slick();
//     });
// })(jQuery, Drupal);